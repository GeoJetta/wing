# Codex Agent Handoff: Aviary FLOPS Weight Estimation Case

## Objective
Take over the generated Aviary FLOPS weight-estimation setup, run it locally, and debug any issues until the script successfully:
1. reads `aircraft_parameters.xlsx`
2. generates `twin_pt6_high_wing_flops.csv`
3. optionally runs the Aviary problem without crashing
4. reports the key mass / weight outputs that are available

## Files in this bundle
- `aviary_flops_weight_estimation.py`
- `twin_pt6_high_wing_flops.csv`
- `advanced_single_aisle_FLOPS.csv`
- `aviary_flops_weight_estimation_README.txt`
- `aircraft_parameters.xlsx`

## Context and intent
This is intended to be a canonical Aviary FLOPS-style aircraft-definition workflow for a:
- twin turboprop
- PT6A-65B engines
- strut-braced high wing
- T-tail
- unpressurized aircraft
- 3500 lb fuel capacity in wing
- 65 ft wingspan
- aspect ratio 12

The current implementation prioritizes a stable FLOPS mass-estimation setup over a deeply modeled turboprop propulsion mission, because Aviary FLOPS empirical mass methods are the core requirement.

## Expected environment
Use Python 3.10 or 3.11 if possible.

Recommended clean environment:
```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
```

## Install steps
Try this first:
```bash
pip install openmdao aviary pandas openpyxl
```

If `aviary` is not the correct package name or is unavailable, install from source:
```bash
git clone https://github.com/OpenMDAO/Aviary.git
cd Aviary
pip install -e .
cd ..
```

Verify importability:
```bash
python - <<'PY'
import aviary
import openmdao
print('aviary ok')
print('openmdao ok')
PY
```

## Primary run commands
First, generate and inspect the CSV only:
```bash
python aviary_flops_weight_estimation.py --xlsx aircraft_parameters.xlsx
```

Then try the full run:
```bash
python aviary_flops_weight_estimation.py --xlsx aircraft_parameters.xlsx --run
```

## Mandatory debugging workflow
If the script fails, do not rewrite it blindly. Use this sequence.

### 1) Confirm Aviary API compatibility
Check whether these imports still exist and whether their module paths changed:
- `aviary.api`
- `AviaryProblem`
- `get_option_defaults`

Open the installed Aviary examples and search for:
- `load_inputs(`
- `check_and_preprocess_inputs(`
- `run_aviary_problem(`
- aircraft CSV examples

If the API has shifted, adapt the script to match the installed version rather than preserving old call signatures.

### 2) Validate CSV variable names against installed metadata
If the run fails on unknown variables, inspect Aviary’s variable metadata and compare every row in `twin_pt6_high_wing_flops.csv` against the installed package.

Search for variable definitions in the installed Aviary source, especially for names beginning with:
- `aircraft:wing:`
- `aircraft:horizontal_tail:`
- `aircraft:vertical_tail:`
- `aircraft:engine:`
- `mission:design:`

Remove or rename stale variables based on the installed version.

### 3) Confirm units
If the run reaches model setup but fails on unit conversions or value ranges:
- verify every CSV row has units recognized by Aviary/OpenMDAO
- confirm mass vs weight conventions (`lbm` vs `lbf`)
- confirm angle units use `deg`
- confirm range uses `NM`
- confirm areas are in `ft**2`

### 4) Reduce to minimum passing case
If the full custom CSV will not run:
- start from `advanced_single_aisle_FLOPS.csv`
- make the smallest edits necessary to convert it into this aircraft
- re-run after each small change
- identify the exact row or group of rows that breaks compatibility

### 5) Isolate propulsion vs geometry issues
This case is mostly a FLOPS geometry/mass case. If engine-model variables break the run:
- temporarily simplify propulsion inputs
- keep engine count at 2
- keep gross-level engine mass / thrust / power assumptions only
- avoid advanced mission-energy or shaft-power details unless required by the installed Aviary version

### 6) Print useful outputs explicitly
Once it runs, add or preserve explicit reporting for:
- gross mass
- operating mass / empty mass if available
- fuel mass
- wing mass
- fuselage mass
- landing gear mass
- tail masses
- propulsion system mass

If exact variable names differ, inspect the final problem outputs and print the closest canonical mass outputs provided by the installed model.

## Reasonable aircraft assumptions already baked in
Keep these unless Aviary requires otherwise:
- wing area = 65^2 / 12 = 352.08 ft^2
- fuel in wing = 3500 lbm
- gross mass approx = 18,500 lbm
- landing mass approx = 15,700 lbm
- 2 x PT6A-65B
- engine mass approx = 520 lbm each for first-pass estimation
- strut bracing factor = 0.8
- high wing
- T-tail
- unpressurized cabin

## Important interpretation note
The source Excel sheet includes:
- `F_tail = 1` with comment `Conventional tail (1 for T-tail)`

Interpret this aircraft as a T-tail configuration, per user instruction and handoff intent.

Also note:
- `w_av = 200` had a comment mentioning avionics plus two PT6A-45R engines

Treat `200 lbm` as avionics package only. Do not double-count engine masses there.

## Acceptance criteria
The takeover is successful when you can provide:
1. a passing run command
2. the final corrected script if edits were needed
3. a note on what changed and why
4. the main mass outputs
5. any remaining limitations or approximations

## Preferred deliverable from the agent
Return:
- corrected `aviary_flops_weight_estimation.py`
- corrected aircraft CSV if modified
- terminal output of successful run
- short debug summary
