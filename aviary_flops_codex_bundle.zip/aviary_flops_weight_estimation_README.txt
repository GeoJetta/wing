Aviary FLOPS weight-estimation setup

Files
- aviary_flops_weight_estimation.py : reads aircraft_parameters.xlsx, derives missing geometry/mass assumptions, and writes a custom Aviary input deck.
- advanced_single_aisle_FLOPS.csv : local fallback template copied from the Aviary example aircraft.
- twin_pt6_high_wing_flops.csv : generated deck for this aircraft.

How to use
1. Install Aviary in your Python environment.
2. Keep these three files in the same directory.
3. Run:
   python aviary_flops_weight_estimation.py --xlsx aircraft_parameters.xlsx --run

What the script does
- Reads the workbook parameters.
- Starts from Aviary's canonical FLOPS single-aisle CSV template.
- Replaces the key geometry, mass, fuel, and configuration values for:
  - high wing
  - strut bracing
  - T-tail
  - twin wing-mounted PT6A-65B-class turboprop installation
- Writes a custom Aviary deck and optionally runs one non-optimization Aviary pass.

Important assumptions added because the workbook does not define them directly
- Wing area = b^2 / AR = 65^2 / 12 = 352.08 ft^2
- Gross mass = 18,500 lbm
- Max touchdown mass = gross mass - 0.8 * fuel = 15,700 lbm
- Horizontal tail area = 105.6 ft^2 using Vh = 0.90
- Vertical tail area = 56.3 ft^2 using Vv = 0.040
- Wing vertical mount location = 1.0 (high wing)
- Horizontal-tail vertical-tail mount location = 1.0 (T-tail)
- Wing strut bracing factor = 0.8
- Engine reference mass = 520 lbm per engine
- Avionics mass = 200 lbm
- Design range = 700 NM for a stable sizing case

Notes
- This is a FLOPS-based first-pass weight model, not a calibrated detailed turboprop mission model.
- The workbook's avionics note appears inconsistent because it mentions avionics plus two PT6A-45R engines while the requested propulsion changed to PT6A-65B; the script therefore treats 200 lbm as avionics only and assigns engine mass separately.
