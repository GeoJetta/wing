from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
from typing import Any

from openpyxl import load_workbook


def read_parameter_sheet(xlsx_path: Path) -> dict[str, Any]:
    wb = load_workbook(xlsx_path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    params: dict[str, Any] = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or row[0] is None:
            continue
        params[str(row[0]).strip()] = row[2]
    return params


def derive_assumptions(params: dict[str, Any]) -> dict[str, float | int | str | bool]:
    # User-provided / fixed configuration
    span = 65.0  # ft
    aspect_ratio = 12.0
    wing_area = span**2 / aspect_ratio
    taper = float(params.get('lambda_w', 1.0))
    mean_chord = wing_area / span
    root_chord = 2.0 * wing_area / (span * (1.0 + taper))
    tc_w = float(params.get('t_c', 0.17))

    # Tail sizing guesses using standard conceptual tail volume coefficients.
    # These are explicit assumptions because the workbook lacks tail planform area.
    htail_arm = 16.25  # ft; from 0.25 * b_w with b_w=65 ft
    vtail_arm = 16.25  # ft; matched to horizontal tail arm for a first-pass commuter layout
    htail_volume_coeff = 0.90
    vtail_volume_coeff = 0.040

    htail_area = htail_volume_coeff * wing_area * mean_chord / htail_arm
    vtail_area = vtail_volume_coeff * wing_area * span / vtail_arm

    htail_ar = 4.5
    vtail_ar = 1.8
    htail_span = math.sqrt(htail_ar * htail_area)
    vtail_span = math.sqrt(vtail_ar * vtail_area)
    htail_chord = htail_area / htail_span
    vtail_chord = vtail_area / vtail_span

    htail_tc = max(0.08, min(0.14, float(params.get('t_ht_max', 0.4)) / htail_chord))
    vtail_tc = max(0.08, min(0.14, float(params.get('t_vt_max', 0.5)) / vtail_chord))

    # Wetted area approximations for a conventional transport-like geometry.
    wing_wetted = 2.05 * wing_area
    htail_wetted = 2.05 * htail_area
    vtail_wetted = 2.05 * vtail_area

    # Mass assumptions.
    fuel_capacity = 3500.0  # lbm in wing per user request
    passengers = int(params.get('N_occ', 19))
    gross_mass = 18500.0  # lbm, reasonable first-pass MTOW for a 19-seat twin PT6 commuter
    touchdown_mass = gross_mass - 0.8 * fuel_capacity

    # PT6A-65B: use user-specified 1400 bshp class for sizing, but a guessed dry mass for FLOPS mass inputs.
    engine_reference_mass = 520.0  # lbm per engine, dry-engine first-pass assumption
    nacelle_length = 8.5  # ft
    nacelle_diameter = 2.4  # ft

    fuselage_width = float(params.get('w_f', 5.83))
    fuselage_height = 6.5  # ft, guessed from 19-seat commuter cross-section
    fuselage_length = float(params.get('l_f', 52.933))

    return {
        'wing_area_ft2': wing_area,
        'wing_span_ft': span,
        'wing_ar': aspect_ratio,
        'wing_root_chord_ft': root_chord,
        'wing_mean_chord_ft': mean_chord,
        'wing_tc': tc_w,
        'wing_wetted_ft2': wing_wetted,
        'wing_mount_location': 1.0,  # high wing per Aviary metadata: 0=low, 1=high
        'wing_has_strut': True,
        'wing_strut_bracing_factor': 0.8,
        'wing_taper_ratio': taper,
        'wing_sweep_deg': float(params.get('Lambda_c_4', 0.0)),
        'ultimate_load_factor': 1.5 * float(params.get('n_z', 3.0)),
        'design_max_mach': float(params.get('M', 0.3)),
        'design_range_nm': 700.0,
        'gross_mass_lbm': gross_mass,
        'touchdown_mass_lbm': touchdown_mass,
        'fuel_capacity_lbm': fuel_capacity,
        'htail_area_ft2': htail_area,
        'htail_ar': htail_ar,
        'htail_span_ft': htail_span,
        'htail_tc': htail_tc,
        'htail_taper_ratio': float(params.get('lambda_ht', 0.9)),
        'htail_sweep_deg': float(params.get('Lambda_ht', 0.0)),
        'htail_wetted_ft2': htail_wetted,
        'htail_mount_location': 1.0 if float(params.get('F_tail', 1)) >= 1.0 else 0.0,
        'vtail_area_ft2': vtail_area,
        'vtail_ar': vtail_ar,
        'vtail_span_ft': vtail_span,
        'vtail_tc': vtail_tc,
        'vtail_taper_ratio': float(params.get('lambda_vt', 0.8)),
        'vtail_sweep_deg': float(params.get('Lambda_vt', 0.0)),
        'vtail_wetted_ft2': vtail_wetted,
        'fuselage_length_ft': fuselage_length,
        'fuselage_width_ft': fuselage_width,
        'fuselage_height_ft': fuselage_height,
        'fuselage_wetted_ft2': float(params.get('S_fus', 1000.0)),
        'passenger_compartment_length_ft': float(params.get('l_fs', 31.0)),
        'num_passengers': passengers,
        'main_gear_oleo_in': 12.0 * float(params.get('L_m', 3.0)),
        'nose_gear_oleo_in': 12.0 * float(params.get('L_n', 3.0)),
        'landing_load_factor': float(params.get('n_l', 5.0)),
        'avionics_mass_lbm': 200.0,
        'engine_num': 2,
        'engine_num_wing': 2,
        'engine_num_fuselage': 0,
        'engine_wing_location_frac': 0.34,
        'engine_reference_mass_lbm': engine_reference_mass,
        'engine_reference_sls_thrust_lbf': float(params.get('T_max', 600.0)),
        'design_takeoff_thrust_per_eng_lbf': float(params.get('T_max', 600.0)),
        'engine_scale_factor': 1.0,
        'nacelle_length_ft': nacelle_length,
        'nacelle_diameter_ft': nacelle_diameter,
        'fixed_gear': False,
        'cruise_mach': float(params.get('M', 0.3)),
        'design_velocity_kn': float(params.get('V_H', 195.0)),
        'pressure_diff_psi': float(params.get('dP', 0.0)),
        'shaft_power_per_eng_hp': float(params.get('P_max', 1400.0)),
    }


def set_value(rows: list[list[str]], name: str, value: Any, units: str | None = None) -> None:
    value_str: str
    if isinstance(value, bool):
        value_str = 'True' if value else 'False'
    elif isinstance(value, float):
        value_str = f'{value:.6f}'.rstrip('0').rstrip('.')
    else:
        value_str = str(value)

    for row in rows:
        if row and row[0].strip() == name:
            row[1:] = [value_str] + ([units] if units is not None else row[2:])
            if units is not None and len(row) < 3:
                row.append(units)
            return

    new_row = [name, value_str]
    if units is not None:
        new_row.append(units)
    rows.append(new_row)


def build_input_deck(template_csv: Path, output_csv: Path, assumptions: dict[str, Any]) -> None:
    with template_csv.open(newline='') as f:
        rows = [row for row in csv.reader(f)]

    # Mission / settings
    set_value(rows, 'settings:mass_method', 'FLOPS', 'unitless')
    set_value(rows, 'settings:aerodynamics_method', 'FLOPS', 'unitless')
    set_value(rows, 'settings:problem_type', 'sizing', 'unitless')
    set_value(rows, 'settings:equations_of_motion', 'energy_state', 'unitless')
    set_value(rows, 'mission:constraints:max_mach', assumptions['design_max_mach'], 'unitless')
    set_value(rows, 'aircraft:design:cruise_mach', assumptions['cruise_mach'], 'unitless')
    set_value(rows, 'aircraft:design:range', assumptions['design_range_nm'], 'NM')
    set_value(rows, 'aircraft:design:gross_mass', assumptions['gross_mass_lbm'], 'lbm')
    set_value(rows, 'aircraft:design:touchdown_mass_max', assumptions['touchdown_mass_lbm'], 'lbm')
    set_value(rows, 'aircraft:design:thrust_takeoff_per_eng', assumptions['design_takeoff_thrust_per_eng_lbf'], 'lbf')

    # Wing
    set_value(rows, 'aircraft:wing:area', assumptions['wing_area_ft2'], 'ft**2')
    set_value(rows, 'aircraft:wing:aspect_ratio', assumptions['wing_ar'], 'unitless')
    set_value(rows, 'aircraft:wing:aspect_ratio_reference', assumptions['wing_ar'], 'unitless')
    set_value(rows, 'aircraft:wing:span', assumptions['wing_span_ft'], 'ft')
    set_value(rows, 'aircraft:wing:taper_ratio', assumptions['wing_taper_ratio'], 'unitless')
    set_value(rows, 'aircraft:wing:sweep', assumptions['wing_sweep_deg'], 'deg')
    set_value(rows, 'aircraft:wing:thickness_to_chord', assumptions['wing_tc'], 'unitless')
    set_value(rows, 'aircraft:wing:thickness_to_chord_reference', assumptions['wing_tc'], 'unitless')
    set_value(rows, 'aircraft:wing:wetted_area', assumptions['wing_wetted_ft2'], 'ft**2')
    set_value(rows, 'aircraft:wing:ultimate_load_factor', assumptions['ultimate_load_factor'], 'unitless')
    set_value(rows, 'aircraft:wing:strut_bracing_factor', assumptions['wing_strut_bracing_factor'], 'unitless')
    set_value(rows, 'aircraft:wing:has_strut', assumptions['wing_has_strut'], 'unitless')
    set_value(rows, 'aircraft:wing:vertical_mount_location', assumptions['wing_mount_location'], 'unitless')

    # Fuselage
    set_value(rows, 'aircraft:fuselage:length', assumptions['fuselage_length_ft'], 'ft')
    set_value(rows, 'aircraft:fuselage:max_width', assumptions['fuselage_width_ft'], 'ft')
    set_value(rows, 'aircraft:fuselage:max_height', assumptions['fuselage_height_ft'], 'ft')
    set_value(rows, 'aircraft:fuselage:wetted_area', assumptions['fuselage_wetted_ft2'], 'ft**2')
    set_value(rows, 'aircraft:fuselage:passenger_compartment_length', assumptions['passenger_compartment_length_ft'], 'ft')
    set_value(rows, 'aircraft:fuselage:num_fuselages', 1, 'unitless')

    # Horizontal tail
    set_value(rows, 'aircraft:horizontal_tail:area', assumptions['htail_area_ft2'], 'ft**2')
    set_value(rows, 'aircraft:horizontal_tail:aspect_ratio', assumptions['htail_ar'], 'unitless')
    set_value(rows, 'aircraft:horizontal_tail:taper_ratio', assumptions['htail_taper_ratio'], 'unitless')
    set_value(rows, 'aircraft:horizontal_tail:sweep', assumptions['htail_sweep_deg'], 'deg')
    set_value(rows, 'aircraft:horizontal_tail:thickness_to_chord', assumptions['htail_tc'], 'unitless')
    set_value(rows, 'aircraft:horizontal_tail:wetted_area', assumptions['htail_wetted_ft2'], 'ft**2')
    set_value(rows, 'aircraft:horizontal_tail:vertical_tail_mount_location', assumptions['htail_mount_location'], 'unitless')

    # Vertical tail
    set_value(rows, 'aircraft:vertical_tail:area', assumptions['vtail_area_ft2'], 'ft**2')
    set_value(rows, 'aircraft:vertical_tail:aspect_ratio', assumptions['vtail_ar'], 'unitless')
    set_value(rows, 'aircraft:vertical_tail:taper_ratio', assumptions['vtail_taper_ratio'], 'unitless')
    set_value(rows, 'aircraft:vertical_tail:sweep', assumptions['vtail_sweep_deg'], 'deg')
    set_value(rows, 'aircraft:vertical_tail:thickness_to_chord', assumptions['vtail_tc'], 'unitless')
    set_value(rows, 'aircraft:vertical_tail:wetted_area', assumptions['vtail_wetted_ft2'], 'ft**2')

    # Landing gear
    set_value(rows, 'aircraft:landing_gear:main_gear_oleo_length', assumptions['main_gear_oleo_in'], 'inch')
    set_value(rows, 'aircraft:landing_gear:nose_gear_oleo_length', assumptions['nose_gear_oleo_in'], 'inch')
    set_value(rows, 'aircraft:landing_gear:fixed_gear', assumptions['fixed_gear'], 'unitless')

    # Crew/payload
    set_value(rows, 'aircraft:crew_and_payload:design:num_passengers', assumptions['num_passengers'], 'unitless')
    set_value(rows, 'aircraft:crew_and_payload:num_passengers', assumptions['num_passengers'], 'unitless')
    set_value(rows, 'aircraft:crew_and_payload:mass_per_passenger_with_bags', 200.0, 'lbm')
    set_value(rows, 'aircraft:crew_and_payload:baggage_mass_per_passenger', 30.0, 'lbm')

    # Fuel
    set_value(rows, 'aircraft:fuel:total_capacity', assumptions['fuel_capacity_lbm'], 'lbm')
    set_value(rows, 'aircraft:fuel:wing_fuel_capacity', assumptions['fuel_capacity_lbm'], 'lbm')
    set_value(rows, 'aircraft:fuel:fuselage_fuel_capacity', 0.0, 'lbm')
    set_value(rows, 'aircraft:fuel:auxiliary_fuel_capacity', 0.0, 'lbm')
    set_value(rows, 'mission:takeoff:fuel', 150.0, 'lbm')

    # Avionics and systems
    set_value(rows, 'aircraft:avionics:mass', assumptions['avionics_mass_lbm'], 'lbm')
    set_value(rows, 'aircraft:air_conditioning:mass', 0.0, 'lbm')
    set_value(rows, 'aircraft:anti_icing:mass_scaler', 0.5, 'unitless')

    # Engines / nacelles
    set_value(rows, 'aircraft:engine:num_engines', assumptions['engine_num'], 'unitless')
    set_value(rows, 'aircraft:engine:num_wing_engines', assumptions['engine_num_wing'], 'unitless')
    set_value(rows, 'aircraft:engine:num_fuselage_engines', assumptions['engine_num_fuselage'], 'unitless')
    set_value(rows, 'aircraft:engine:wing_locations', assumptions['engine_wing_location_frac'], 'unitless')
    set_value(rows, 'aircraft:engine:reference_mass', assumptions['engine_reference_mass_lbm'], 'lbm')
    set_value(rows, 'aircraft:engine:reference_sls_thrust', assumptions['engine_reference_sls_thrust_lbf'], 'lbf')
    set_value(rows, 'aircraft:engine:scaled_sls_thrust', assumptions['engine_reference_sls_thrust_lbf'], 'lbf')
    set_value(rows, 'aircraft:engine:scale_factor', assumptions['engine_scale_factor'], 'unitless')
    set_value(rows, 'aircraft:nacelle:avg_length', assumptions['nacelle_length_ft'], 'ft')
    set_value(rows, 'aircraft:nacelle:avg_diameter', assumptions['nacelle_diameter_ft'], 'ft')

    with output_csv.open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(rows)


def try_run_aviary(input_deck: Path) -> None:
    try:
        from aviary.api import default_energy_state_phase_info as phase_info
        from aviary.core.aviary_problem import AviaryProblem
        from aviary.variable_info.variables import Aircraft, Mission
    except Exception as exc:
        print('Aviary is not installed in this environment, so the deck was generated but not executed.')
        print(f'Import error: {exc}')
        return

    prob = AviaryProblem()
    prob.load_inputs(str(input_deck), phase_info)
    prob.check_and_preprocess_inputs()
    prob.build_model()
    prob.setup()
    prob.run_aviary_problem(run_driver=False, simulate=False, make_plots=False)

    candidates = [
        Aircraft.Design.STRUCTURE_MASS,
        Aircraft.Design.EMPTY_MASS,
        Aircraft.Fuel.FUEL_SYSTEM_MASS,
        Aircraft.LandingGear.TOTAL_MASS,
        Mission.Design.GROSS_MASS,
        Mission.Design.OPERATING_MASS,
    ]

    print('\nAviary outputs:')
    for key in candidates:
        try:
            value = prob.get_val(key)
            print(f'  {key} = {value}')
        except Exception:
            pass


def main() -> None:
    parser = argparse.ArgumentParser(description='Build and optionally run a FLOPS-based Aviary input deck from the parameter workbook.')
    parser.add_argument('--xlsx', type=Path, default=Path('aircraft_parameters.xlsx'))
    parser.add_argument('--template', type=Path, default=Path('advanced_single_aisle_FLOPS.csv'))
    parser.add_argument('--out', type=Path, default=Path('twin_pt6_high_wing_flops.csv'))
    parser.add_argument('--run', action='store_true', help='Run Aviary after writing the deck.')
    args = parser.parse_args()

    params = read_parameter_sheet(args.xlsx)
    assumptions = derive_assumptions(params)
    build_input_deck(args.template, args.out, assumptions)

    print(f'Wrote Aviary input deck to: {args.out.resolve()}')
    print('Key derived assumptions:')
    for key in [
        'wing_area_ft2', 'gross_mass_lbm', 'touchdown_mass_lbm', 'fuel_capacity_lbm',
        'htail_area_ft2', 'vtail_area_ft2', 'engine_reference_mass_lbm', 'wing_mount_location',
        'wing_strut_bracing_factor', 'htail_mount_location'
    ]:
        print(f'  {key}: {assumptions[key]}')

    if args.run:
        try_run_aviary(args.out)


if __name__ == '__main__':
    main()
